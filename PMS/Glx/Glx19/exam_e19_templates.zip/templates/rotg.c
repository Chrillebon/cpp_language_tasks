#include <stdlib.h>
#include <math.h>

void rotg(double a, double b, double * c, double * s){
  /* Insert code here */
}
