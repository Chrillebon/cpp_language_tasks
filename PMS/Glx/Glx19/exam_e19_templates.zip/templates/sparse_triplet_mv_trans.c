#include "sparse_triplet.h"

void sparse_triplet_mv_trans(
    const struct sparse_triplet *A,
    const double *x,
    double *y) {
    /* Insert code here */
    return;
}
